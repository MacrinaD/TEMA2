package Tema3;

import java.util.LinkedList;
import java.util.Queue;

public class QueueEx {

    static int VerifyQueue(Queue q1, Queue q2) { //Verify the queues starting with first letter from first queue and
        System.out.println(q1);                  //last letter from second queue
        System.out.println(q2);
        while (!q1.isEmpty() & !q2.isEmpty())
            {
                if (q1.remove()!= q2.remove()){
                    return 0;
                     }
            }
        return 1;
    }



    public static void main(String[] args) {
        int nr, i;
        String sir = new String("aaadaaa");
        sir = sir.toLowerCase();
        System.out.println(sir);
        Queue coada = new LinkedList(); //The first queue in which I will store the first half of the string
        Queue coada2 = new LinkedList();//The second queue in which I will store the second half of the string


        //to store the first half we verify to what position the counter counts
        if ((sir.length()) % 2 == 0)
            nr = (sir.length()) / 2;
        else
            nr = (sir.length() - 1) / 2;


        for (i = 0; i < nr; i++) {
            coada.add(sir.charAt(i));
        }

        ////to store the second half we verify to what position the counter counts
        if ((sir.length()) % 2 == 0)
            nr = (sir.length()) / 2;
        else
            nr = (sir.length() + 1) / 2;


        for (i = sir.length() - 1; i >= nr; i--) {
            coada2.add(sir.charAt(i));
        }

        if (VerifyQueue(coada, coada2) == 0)
            System.out.println("Sirul nu este un palindrom!");
        else
            System.out.println("Sirul este un palindrom!");


    }



}

