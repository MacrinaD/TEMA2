package Tema3;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Homework3 {
    static void printStack(Stack s){

        while(!s.empty()){
            System.out.println(s.pop());
        }

    }
    public static void main(String[] args) {
        Stack word=new Stack();
        Queue q=new LinkedList();
        word.push("I");
        word.push("n");
        word.push("c");
        word.push("o");
        word.push("m");
        word.push("p");
        word.push("r");
        word.push("e");
        word.push("h");
        word.push("e");
        word.push("n");
        word.push("s");
        word.push("i");
        word.push("b");
        word.push("i");
        word.push("l");
        word.push("i");
        word.push("t");
        word.push("i");
        word.push("e");
        word.push("s");

        printStack(word);






    }
}
