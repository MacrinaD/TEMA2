package Tema3;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class ListsEx {
    public static void main(String []args)
    {
        List<Integer> l=new LinkedList<Integer>();
        l.add(400);
        l.add(1,-3);
        l.add(2,4);
        l.add(900);
        l.add(4,3);
        l.add(5,7);
        Collections.sort(l);
        System.out.println(l);

        ListIterator li=l.listIterator(0);
        ListIterator li2=l.listIterator(l.size()-1);
        System.out.println(li.next());


    }

}
