package Exercises_Module2;

import java.util.Scanner;

public class Homework {

    public static void areaRectagle(double length, double width){
        double area=length*width;
        System.out.println("Area of rectangle is: " +area);

    }
    public static void perimeterRectangle(double length, double width){
        double perimeter=2*(length+width);
        System.out.println("Perimeter of Rectangle is: " +perimeter);
    }
    public static double areaofHexagon(double a){
        return (6*(a*a))/(4*Math.tan(Math.PI/6)); //using Java Class Math for different calculations
    }
    public static double distance(double lat1 ,double log1,double lat2,double log2){
        //convert the points to radians
        lat1=Math.toRadians(lat1);
        log1=Math.toRadians(log1);
        lat2=Math.toRadians(lat2);
        log2=Math.toRadians(log2);

        double earthRadius=6371.01; //Kilometers
        return earthRadius*Math.acos(Math.sin(lat1)*Math.sin(lat2)+Math.cos(lat1)*Math.cos(lat2)*Math.cos(log1-log2));

    }
    public static void palindrom(int n) {
        String reverse=""; //initialization of an object belonging to the String class
        String numar=String.valueOf(n); //This method returns a string representation of passed arguments such as array etc
        if (n > 0){
            for(int i1=numar.length()-1;i1>=0;i1--){
                reverse=reverse+numar.charAt(i1);//It returns the character at the specified index.
            }
            if(numar.equals(reverse)) //Compares the string with the specified string
                System.out.println("The number is a palindrome");
            else
                System.out.println("The number is not a palindrome");
        }
    }






    public static void main(String[] args) {


        //Exercise 1
        System.out.println("///Exercise 1"+"\n");
        double x=6,y=10;
        areaRectagle(x,y);
        perimeterRectangle(x,y);

        //Area of Hexagon
        // Declare the object and initialize with
        // predefined standard input object
        Scanner input =new Scanner(System.in); //
        System.out.print("Input the length of a side of a hexagon: ");
        double a=input.nextDouble(); //The method scans the next token of the input as a Double.
        System.out.println("The area of the hexagon is: " +areaofHexagon(a)+"\n");

        //Exercise 2

       // caaSystem.out.println("\n");

        System.out.println("//Exercise 2"+"\n");

        System.out.print("Input the latitude of coordinate 1: ");
        double lat1=input.nextDouble();//// Numerical data input
        System.out.print("Input the longitude of coordinate 1: ");
        double log1=input.nextDouble();
        System.out.print("Input the latitude of coordinate 2: ");
        double lat2=input.nextDouble();
        System.out.print("Input the longitude of coordinate 2: ");
        double log2=input.nextDouble();

        System.out.println("The distance is: " + distance(lat1,log1,lat2,log2) + "\n");

        //Exercise 3
        System.out.println("//Exercise 3"+"\n");
        System.out.print("Enter a string:");

        Scanner input2 = new Scanner(System.in);
        String str = input2.nextLine();// String input
        String reverse = "";
        for(int i = str.length() - 1; i >= 0; i--)
        {
            reverse = reverse + str.charAt(i);
        }

        System.out.print("Reversed string is:");
        System.out.println(reverse + "\n");

        //Exercise 4
        System.out.println("//Exercise 4" + "\n");
        for(int j=1;j<=99;j++)
        {
            if(j%2!=0)
            {
                System.out.print(j+ " ");
            }

        }
        //Exercise 5

        System.out.println("\n");
        System.out.println("//Exercise 5" + "\n");

        System.out.print("A string: ");
        String strr=input2.nextLine();// This method returns the rest of the current line, excluding any line separator at the end.
        strr=strr.toLowerCase(); //It converts the string to lower case string using the rules defined by given locale.
        System.out.print("The result: ");
        System.out.print(strr);

        //Exercise 6

        System.out.println("\n");
        System.out.println("//Exercise 6" + "\n");
        for(int k=1;k<=100;k++)
        {
            if(k%3==0 && k%5==0)
            {
                System.out.printf("\n%d fizz buzz", k);
            }
            else if(k%3==0)
            {
                System.out.printf("\n%d Fizz", k);
            }
            else if(k%5==0)
            {
                System.out.printf("\n%d Buzz", k);
            }

        }
        //Exercise 7

        System.out.println("\n");
        System.out.println("//Exercise 7" + "\n");
        System.out.println("Input Original Number: ");
        int n=input2.nextInt();//The method scans the next token of the input as a Int.
        System.out.println("The result is: ");
        palindrom(n);









    }
}